package com.example.app1920

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
