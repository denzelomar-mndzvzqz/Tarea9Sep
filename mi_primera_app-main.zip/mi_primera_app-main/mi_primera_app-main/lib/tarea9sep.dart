import 'dart:math';
import 'package:flutter/material.dart';
import 'package:app1920/constantes.dart' as cons;

class Principal extends StatefulWidget {
  const Principal({super.key});

  @override
  State<Principal> createState() => _PrincipalState();
}

class _PrincipalState extends State<Principal> {
  final List<Color> baseColors = [
    cons.azul1,
    cons.azul2,
    cons.azul3,
    cons.gris,
    cons.negro,
  ];

  late List<Color> fila1;
  late List<Color> fila2;
  late List<Color> fila3;
  late List<Color> fila4;
  late List<Color> fila5;
  late List<Color> fila6;

  @override
  void initState() {
    super.initState();
    final random = Random();
    fila1 = List.generate(4, (_) => baseColors[random.nextInt(baseColors.length)]);
    fila2 = List.generate(4, (_) => baseColors[random.nextInt(baseColors.length)]);
    fila3 = List.generate(4, (_) => baseColors[random.nextInt(baseColors.length)]);
    fila4 = List.generate(4, (_) => baseColors[random.nextInt(baseColors.length)]);
    fila5 = List.generate(4, (_) => baseColors[random.nextInt(baseColors.length)]);
    fila6 = List.generate(4, (_) => baseColors[random.nextInt(baseColors.length)]);
  }

  Color getRandomColor() {
    final random = Random();
    return baseColors[random.nextInt(baseColors.length)];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          // Fila 1
          Expanded(
            flex: 2,
            child: Row(
              children: List.generate(4, (i) {
                return Expanded(
                  flex: 3,
                  child: InkWell(
                    onTap: () {
                      setState(() {
                        fila1[i] = getRandomColor();
                      });
                    },
                    child: Container(color: fila1[i]),
                  ),
                );
              }),
            ),
          ),

          // Fila 2 (no hace nada)
          Expanded(
            flex: 2,
            child: Row(
              children: List.generate(4, (i) {
                return Expanded(
                  flex: 3,
                  child: Container(color: fila2[i]),
                );
              }),
            ),
          ),

          // Fila 3
          Expanded(
            flex: 2,
            child: Row(
              children: [
                Expanded(
                  flex: 3,
                  child: InkWell(
                    onTap: () {
                      setState(() {
                        final temp = fila3[0];
                        fila3[0] = fila3[3];
                        fila3[3] = temp;
                      });
                    },
                    child: Container(color: fila3[0]),
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: InkWell(
                    onTap: () {
                      setState(() {
                        final temp = fila3[1];
                        fila3[1] = fila3[2];
                        fila3[2] = temp;
                      });
                    },
                    child: Container(color: fila3[1]),
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: InkWell(
                    onTap: () {
                      setState(() {
                        final temp = fila3[1];
                        fila3[1] = fila3[2];
                        fila3[2] = temp;
                      });
                    },
                    child: Container(color: fila3[2]),
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: InkWell(
                    onTap: () {
                      setState(() {
                        final temp = fila3[0];
                        fila3[0] = fila3[3];
                        fila3[3] = temp;
                      });
                    },
                    child: Container(color: fila3[3]),
                  ),
                ),
              ],
            ),
          ),

          // Fila 4 (no hace nada)
          Expanded(
            flex: 2,
            child: Row(
              children: List.generate(4, (i) {
                return Expanded(
                  flex: 3,
                  child: Container(color: fila4[i]),
                );
              }),
            ),
          ),

          // Fila 5
          Expanded(
            flex: 2,
            child: Row(
              children: [
                Expanded(
                  flex: 3,
                  child: InkWell(
                    onTap: () {
                      setState(() {
                        final newColor = getRandomColor();
                        for (int j = 1; j < 4; j++) {
                          fila5[j] = newColor;
                        }
                      });
                    },
                    child: Container(color: fila5[0]),
                  ),
                ),
                Expanded(flex: 3, child: Container(color: fila5[1])),
                Expanded(flex: 3, child: Container(color: fila5[2])),
                Expanded(flex: 3, child: Container(color: fila5[3])),
              ],
            ),
          ),

          // Fila 6 (no hace nada)
          Expanded(
            flex: 2,
            child: Row(
              children: List.generate(4, (i) {
                return Expanded(
                  flex: 3,
                  child: Container(color: fila6[i]),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }
}
