import 'package:flutter/material.dart';

///Colores
const negro = Colors.black;
const gris = Colors.grey;
const blanco = Colors.white;
const azul1 = Color(0xFF2D6FA1); //Colors.blue;
const azul2 = Color(0xFF77A8CE);
const azul3 = Color(0x6677A8CE);
const azul4 = Color(0xFF2DA193);

const usuario = '';
const pass = '';
